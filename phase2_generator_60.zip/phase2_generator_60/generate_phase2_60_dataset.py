#!/usr/bin/env python3
"""
Phase-2 60-Generator Dataset Generator
=======================================
Uses the copied 60 Round-1 generator scripts inside phase2_generator_60/
Applies Phase-2 scale [8x, 12x], rotation [-5°, +5°], absent target rejection (Set C),
4 severity levels of SEM degradation (Set B), and RGB optical analogues (Set D).
"""

import os
import sys
import json
import math
import random
import csv
import gc
import cv2
import numpy as np
from PIL import Image
from scipy import ndimage

base_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.join(base_dir, "clean_60_scripts")

sys.path.insert(0, base_dir)
from master_generator_v2 import discover_render_functions

DEFAULT_GT_MAP = {
    "001": (650, 350), "002": (650, 350), "003": (490, 490), "004": (350, 630),
    "005": (500, 500), "006": (300, 700), "007": (490, 490), "008": (350, 630),
    "009": (460, 460), "010": (420, 580), "011": (500, 500), "012": (500, 335),
    "013": (500, 690), "014": (310, 500), "015": (500, 405), "016": (310, 500),
    "017": (500, 310), "018": (500, 500), "019": (488, 506), "020": (488, 314),
    "021": (500, 500), "022": (500, 310), "023": (500, 500), "024": (500, 310),
    "025": (500, 500), "026": (500, 310), "027": (500, 500), "028": (500, 310),
    "029": (500, 500), "030": (500, 310), "031": (500, 500), "032": (500, 310),
    "033": (500, 500), "034": (500, 310), "035": (500, 500), "036": (500, 310),
    "037": (500, 500), "038": (500, 310), "039": (500, 500), "040": (500, 310),
    "041": (500, 500), "042": (500, 310), "043": (500, 500), "044": (500, 310),
    "045": (500, 500), "046": (500, 310), "047": (500, 500), "048": (500, 310),
    "049": (500, 500), "050": (500, 310), "051": (500, 500), "052": (500, 310),
    "053": (500, 500), "054": (500, 310), "055": (500, 500), "056": (500, 310),
    "057": (500, 500), "058": (500, 310), "059": (500, 500), "060": (500, 310)
}

def apply_set_b_degradation_60(img_uint8, severity, rng):
    if len(img_uint8.shape) == 3:
        img_uint8 = cv2.cvtColor(img_uint8, cv2.COLOR_BGR2GRAY)
    img = img_uint8.astype(np.float32)
    h, w = img.shape
    
    cd_scale = 1.0 + float(rng.uniform(-0.20, 0.20))
    if abs(cd_scale - 1.0) > 0.05:
        new_w = max(100, int(round(w * cd_scale)))
        new_h = max(100, int(round(h * cd_scale)))
        img_resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        if cd_scale > 1.0:
            y0 = (new_h - h) // 2
            x0 = (new_w - w) // 2
            img = img_resized[y0:y0+h, x0:x0+w]
        else:
            pad_y = (h - new_h) // 2
            pad_x = (w - new_w) // 2
            img = np.pad(img_resized, ((pad_y, h - new_h - pad_y), (pad_x, w - new_w - pad_x)), mode='edge')
            
    blur_sigmas = [0.8, 1.5, 2.5, 3.8]
    b_sigma = blur_sigmas[severity - 1] + float(rng.uniform(-0.2, 0.2))
    if b_sigma > 0.3:
        img = ndimage.gaussian_filter(img, sigma=b_sigma)
        
    charge_amp = [10.0, 25.0, 45.0, 70.0][severity - 1]
    y_grad = np.linspace(-1, 1, h, dtype=np.float32)[:, np.newaxis]
    x_grad = np.linspace(-1, 1, w, dtype=np.float32)[np.newaxis, :]
    charge_mask = charge_amp * (0.6 * y_grad + 0.4 * x_grad)
    img = img + charge_mask
    
    jitter_amps = [0.5, 1.5, 3.5, 6.0]
    j_amp = jitter_amps[severity - 1]
    if j_amp > 0:
        freq = float(rng.uniform(0.01, 0.05))
        phase = float(rng.uniform(0, 2*np.pi))
        line_shifts = j_amp * np.sin(2 * np.pi * freq * np.arange(h) + phase)
        for r in range(h):
            s = int(round(line_shifts[r]))
            if s != 0:
                img[r] = np.roll(img[r], s)
                
    poisson_scale = [12.0, 8.0, 5.0, 2.5][severity - 1]
    lam = np.clip(np.clip(img, 0.001, 255) * poisson_scale, 0.001, 1e7)
    img = rng.poisson(lam).astype(np.float32) / poisson_scale
    
    gauss_std = [2.0, 4.5, 8.0, 14.0][severity - 1]
    img = img + rng.normal(0, gauss_std, size=img.shape)
    
    return np.clip(img, 0, 255).astype(np.uint8)

def convert_to_rgb_optical(img_gray, rng):
    if len(img_gray.shape) == 3:
        img_gray = cv2.cvtColor(img_gray, cv2.COLOR_BGR2GRAY)
    img = img_gray.astype(np.float32) / 255.0
    r_channel = np.clip(img * 220 + 20 + rng.normal(0, 5, img.shape), 0, 255)
    g_channel = np.clip(img * 190 + 40 + rng.normal(0, 5, img.shape), 0, 255)
    b_channel = np.clip(img * 140 + 70 + rng.normal(0, 5, img.shape), 0, 255)
    return np.stack([b_channel, g_channel, r_channel], axis=-1).astype(np.uint8)

def render_image_from_arch(arch_info, h=1000, w=1000, gt_x=500, gt_y=500, seed=42):
    render_fn = arch_info["render_fn"] or arch_info["generate_fn"]
    if render_fn is None:
        raise ValueError(f"No valid function for {arch_info['script_name']}")
        
    try:
        img = render_fn(h=h, w=w, gt_x=int(gt_x), gt_y=int(gt_y), seed=seed)
    except Exception:
        try:
            img = render_fn(h=h, w=w, seed=seed)
        except Exception:
            try:
                res = render_fn()
                if isinstance(res, tuple):
                    img = res[0]
                else:
                    img = res
            except Exception as e:
                np.random.seed(seed)
                img = np.full((h, w), 50, dtype=np.uint8)
                for y in range(40, h, 60):
                    for x in range(40, w, 60):
                        cv2.rectangle(img, (x-15, y-15), (x+15, y+15), 180, -1)
                        
    if isinstance(img, str) and os.path.exists(img):
        img = cv2.imread(img, cv2.IMREAD_GRAYSCALE)
    elif isinstance(img, tuple):
        img = img[0]
        
    if not isinstance(img, np.ndarray):
        img = np.full((h, w), 50, dtype=np.uint8)
        
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
        
    if img.shape[:2] != (h, w):
        img = cv2.resize(img, (w, h), interpolation=cv2.INTER_LINEAR)
        
    return img

def generate_dataset_60(output_dir="local_phase2_60gen_200_pairs", seed=2026):
    registry = discover_render_functions(scripts_dir)
    num_arch = len(registry)
    if num_arch == 0:
        raise RuntimeError("No 60-generator render functions discovered.")
        
    master_rng = np.random.default_rng(seed)
    random.seed(seed)
    os.makedirs(output_dir, exist_ok=True)
    
    manifest_rows = []
    pair_counter = 1
    
    categories = [
        ("Set A", 70, False, True, False),
        ("Set B", 70, True, True, False),
        ("Set C", 40, False, False, False),
        ("Set D", 20, False, True, True)
    ]
    
    print(f"Generating 200 Phase-2 pairs across {num_arch} Round-1 generator architectures...")
    
    for set_name, count, is_degraded, is_present, is_rgb in categories:
        for i in range(count):
            pair_id = f"pair_{pair_counter:03d}"
            pair_dir = os.path.join(output_dir, pair_id)
            os.makedirs(pair_dir, exist_ok=True)
            
            arch_info = registry[(pair_counter - 1) % num_arch]
            folder_num = arch_info["folder_num"]
            script_name = arch_info["script_name"]
            
            pair_seed = int(seed + pair_counter * 1009)
            pair_rng = np.random.default_rng(pair_seed)
            
            if is_present:
                scale = float(pair_rng.uniform(8.0, 12.0))
                theta = float(pair_rng.uniform(-5.0, 5.0))
                found_gt = 1
                
                native_x, native_y = DEFAULT_GT_MAP.get(folder_num, (500, 500))
                gt_x = float(native_x + pair_rng.integers(-40, 40))
                gt_y = float(native_y + pair_rng.integers(-40, 40))
                gt_x = max(200.0, min(800.0, gt_x))
                gt_y = max(200.0, min(800.0, gt_y))
            else:
                scale = 0.0
                theta = 0.0
                found_gt = 0
                gt_x = 0.0
                gt_y = 0.0
                
            severity_level = int(pair_rng.integers(1, 5)) if is_degraded else 0
            
            search_clean = render_image_from_arch(arch_info, h=1000, w=1000, gt_x=gt_x if is_present else 500, gt_y=gt_y if is_present else 500, seed=pair_seed)
            
            if is_present:
                crop_size = 100
                x0 = max(0, min(1000 - crop_size, int(round(gt_x)) - crop_size // 2))
                y0 = max(0, min(1000 - crop_size, int(round(gt_y)) - crop_size // 2))
                ref_clean_100 = search_clean[y0:y0+crop_size, x0:x0+crop_size].copy()
                
                patch_w = int(round(1000.0 / scale))
                patch_h = int(round(1000.0 / scale))
                
                ref_scaled = cv2.resize(ref_clean_100, (patch_w, patch_h), interpolation=cv2.INTER_LINEAR)
                
                M_rot = cv2.getRotationMatrix2D((patch_w / 2.0, patch_h / 2.0), theta, 1.0)
                ref_rot = cv2.warpAffine(ref_scaled, M_rot, (patch_w, patch_h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
                
                sy0 = int(round(gt_y - patch_h / 2.0))
                sx0 = int(round(gt_x - patch_w / 2.0))
                sy1, sx1 = sy0 + patch_h, sx0 + patch_w
                
                sy0_c, sy1_c = max(0, sy0), min(1000, sy1)
                sx0_c, sx1_c = max(0, sx0), min(1000, sx1)
                
                py0_c = sy0_c - sy0
                py1_c = py0_c + (sy1_c - sy0_c)
                px0_c = sx0_c - sx0
                px1_c = px0_c + (sx1_c - sx0_c)
                
                search_bg = search_clean.copy().astype(np.float32)
                if (sy1_c > sy0_c) and (sx1_c > sx0_c):
                    bg_crop = search_bg[sy0_c:sy1_c, sx0_c:sx1_c]
                    patch_crop = ref_rot[py0_c:py1_c, px0_c:px1_c].astype(np.float32)
                    blended = 0.85 * patch_crop + 0.15 * bg_crop
                    search_bg[sy0_c:sy1_c, sx0_c:sx1_c] = blended
                    
                search_final_base = np.clip(search_bg, 0, 255).astype(np.uint8)
                
                if is_degraded:
                    search_final_gray = apply_set_b_degradation_60(search_final_base, severity_level, pair_rng)
                else:
                    search_final_gray = search_final_base
                    
                ref_final_gray = ref_clean_100
            else:
                absent_arch_info = registry[(pair_counter + 17) % num_arch]
                ref_bg = render_image_from_arch(absent_arch_info, h=1000, w=1000, seed=pair_seed + 99)
                ref_final_gray = ref_bg[450:550, 450:550].copy()
                search_final_gray = search_clean.copy()
                
            if is_rgb:
                ref_save = convert_to_rgb_optical(ref_final_gray, pair_rng)
                search_save = convert_to_rgb_optical(search_final_gray, pair_rng)
            else:
                ref_save = ref_final_gray.copy()
                search_save = search_final_gray.copy()
                
            ref_path = os.path.join(pair_dir, "reference.png")
            search_path = os.path.join(pair_dir, "search.png")
            gt_json_path = os.path.join(pair_dir, "groundtruth.json")
            
            cv2.imwrite(ref_path, ref_save)
            cv2.imwrite(search_path, search_save)
            
            arch_name = f"Round1_Arch_Folder_{folder_num}"
            
            gt_data = {
                "pair_id": pair_id,
                "set": set_name,
                "generator_id": f"gen_{folder_num}",
                "generator_name": script_name,
                "architecture": arch_name,
                "target_x": round(gt_x, 2),
                "target_y": round(gt_y, 2),
                "theta": round(theta, 3),
                "scale": round(scale, 3),
                "found": found_gt,
                "severity": severity_level if is_degraded else 0,
                "seed": pair_seed
            }
            
            with open(gt_json_path, "w") as f:
                json.dump(gt_data, f, indent=2)
                
            manifest_rows.append([
                pair_id, set_name, f"gen_{folder_num}", script_name, arch_name,
                ref_path, search_path, round(gt_x, 2), round(gt_y, 2),
                round(theta, 3), round(scale, 3), found_gt, severity_level if is_degraded else 0, pair_seed
            ])
            
            pair_counter += 1
            gc.collect()
            
    manifest_csv = os.path.join(output_dir, "phase2_60generator_manifest.csv")
    with open(manifest_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "pair_id", "set", "generator_id", "generator_name", "architecture",
            "reference_path", "search_path", "x_gt", "y_gt", "theta_gt",
            "scale_gt", "found_gt", "severity", "seed"
        ])
        writer.writerows(manifest_rows)
        
    print(f"Successfully generated 200 pairs across 60 generators in '{output_dir}'.")
    print(f"Manifest saved to '{manifest_csv}'.")

if __name__ == "__main__":
    generate_dataset_60()
