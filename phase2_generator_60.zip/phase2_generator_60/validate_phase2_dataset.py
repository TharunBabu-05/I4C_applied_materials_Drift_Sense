#!/usr/bin/env python3
"""
Phase-2 Dataset Validation Script
==================================
Validates the generated Phase-2 dataset against the 15 required checks.
Produces phase2_dataset_validation.md report.

Usage:
    python phase2_generator_60/validate_phase2_dataset.py --dataset_dir phase2_dataset
"""

import argparse
import csv
import json
import os
import sys

import cv2
import numpy as np


def validate_phase2_dataset(dataset_dir, expected_pairs=15000):
    report_lines = []
    issues = []
    passed = 0
    failed = 0

    def check(name, condition, detail=""):
        nonlocal passed, failed
        if condition:
            report_lines.append(f"- [x] **PASS** — {name}")
            if detail:
                report_lines.append(f"  - {detail}")
            passed += 1
        else:
            report_lines.append(f"- [ ] **FAIL** — {name}")
            if detail:
                report_lines.append(f"  - {detail}")
            issues.append(name)
            failed += 1

    print(f"Validating Phase-2 dataset at: {os.path.abspath(dataset_dir)}")

    # ── Load manifest ──────────────────────────────────────────────────────
    manifest_path = os.path.join(dataset_dir, "dataset_manifest.json")
    if not os.path.exists(manifest_path):
        print("ERROR: dataset_manifest.json not found. Run generation first.")
        sys.exit(1)

    with open(manifest_path) as f:
        manifest = json.load(f)

    pairs = manifest.get("pairs", [])
    n = len(pairs)

    # ── CHECK 1: Correct number of pairs ──────────────────────────────────
    check("1. Correct number of pairs",
          n == expected_pairs,
          f"Found {n}, expected {expected_pairs}")

    # ── CHECK 2: All 60 generators represented ─────────────────────────────
    gen_ids = set(p.get("generator_id", "") for p in pairs)
    # Expect gen_001 through gen_060
    expected_gens = {f"gen_{str(i).zfill(3)}" for i in range(1, 61)}
    missing_gens = expected_gens - gen_ids
    check("2. All 60 generators represented",
          len(missing_gens) == 0,
          f"Missing generators: {sorted(missing_gens)[:10]}" if missing_gens
          else f"All generators found: {len(gen_ids)} unique")

    # ── CHECK 3: Scale distribution covers [8, 12] ─────────────────────────
    scales = [p["scale_gt"] for p in pairs if p.get("found_gt", 1) == 1]
    if scales:
        scale_min, scale_max = min(scales), max(scales)
        scale_ok = scale_min >= 7.9 and scale_max <= 12.1
        bins = {"8-9": 0, "9-10": 0, "10-11": 0, "11-12": 0}
        for s in scales:
            if s < 9: bins["8-9"] += 1
            elif s < 10: bins["9-10"] += 1
            elif s < 11: bins["10-11"] += 1
            else: bins["11-12"] += 1
        check("3. Scale distribution covers [8, 12]",
              scale_ok,
              f"Range [{scale_min:.2f}, {scale_max:.2f}], bins={bins}")
    else:
        check("3. Scale distribution covers [8, 12]", False, "No present pairs found")

    # ── CHECK 4: Rotation distribution covers [-5, +5] ─────────────────────
    thetas = [p["theta_gt"] for p in pairs if p.get("found_gt", 1) == 1]
    if thetas:
        th_min, th_max = min(thetas), max(thetas)
        rot_ok = th_min >= -5.1 and th_max <= 5.1
        check("4. Rotation distribution covers [-5°, +5°]",
              rot_ok,
              f"Range [{th_min:.2f}°, {th_max:.2f}°]")
    else:
        check("4. Rotation distribution covers [-5°, +5°]", False, "No present pairs")

    # ── CHECK 5: Present/absent ratio ─────────────────────────────────────
    present_count = sum(1 for p in pairs if p.get("found_gt", 1) == 1)
    absent_count = n - present_count
    absent_pct = 100.0 * absent_count / max(n, 1)
    ratio_ok = 15.0 <= absent_pct <= 25.0
    check("5. Present/absent ratio ~80/20",
          ratio_ok,
          f"Present={present_count} ({100-absent_pct:.1f}%), "
          f"Absent={absent_count} ({absent_pct:.1f}%)")

    # ── CHECK 6: Correct image dimensions ─────────────────────────────────
    # Sample 20 pairs to check dimensions
    sample_indices = list(range(min(20, n)))
    dim_ok = True
    dim_issues = []
    for p in [pairs[i] for i in sample_indices]:
        split = p.get("split", "train")
        pair_id = p["pair_id"]
        search_path = os.path.join(dataset_dir, split, pair_id, "search.png")
        if os.path.exists(search_path):
            img = cv2.imread(search_path, cv2.IMREAD_GRAYSCALE)
            if img is None or img.shape != (1000, 1000):
                dim_ok = False
                dim_issues.append(f"{pair_id}: {img.shape if img is not None else 'None'}")
    check("6. Search images are 1000×1000",
          dim_ok,
          f"Checked {len(sample_indices)} pairs. Issues: {dim_issues}" if not dim_ok
          else f"Checked {len(sample_indices)} pairs, all 1000×1000")

    # ── CHECK 7: Reference is 100×100 ────────────────────────────────────
    ref_dim_ok = True
    ref_issues = []
    for p in [pairs[i] for i in sample_indices]:
        split = p.get("split", "train")
        pair_id = p["pair_id"]
        ref_path = os.path.join(dataset_dir, split, pair_id, "reference.png")
        if os.path.exists(ref_path):
            img = cv2.imread(ref_path, cv2.IMREAD_GRAYSCALE)
            if img is None or img.shape != (100, 100):
                ref_dim_ok = False
                ref_issues.append(f"{pair_id}: {img.shape if img is not None else 'None'}")
    check("7. Reference images are 100×100",
          ref_dim_ok,
          f"Issues: {ref_issues}" if not ref_dim_ok
          else f"Checked {len(sample_indices)} pairs, all 100×100")

    # ── CHECK 8: Ground truth coordinates valid ────────────────────────────
    gt_ok = True
    gt_issues = []
    for p in pairs[:100]:
        if p.get("found_gt", 1) == 1:
            x, y = p.get("center_x", -1), p.get("center_y", -1)
            if not (0 <= x <= 1000 and 0 <= y <= 1000):
                gt_ok = False
                gt_issues.append(f"{p['pair_id']}: ({x},{y})")
    check("8. Ground truth coordinates in [0, 1000]",
          gt_ok,
          f"Issues: {gt_issues[:5]}" if not gt_ok
          else "First 100 pairs all valid")

    # ── CHECK 9: Ground truth rotation correct ─────────────────────────────
    rot_valid = all(-5.01 <= p.get("theta_gt", 0) <= 5.01 for p in pairs)
    check("9. Ground truth rotation in [-5°, +5°]",
          rot_valid,
          "All pairs within range" if rot_valid else "Some theta_gt out of range")

    # ── CHECK 10: Ground truth scale correct ───────────────────────────────
    scale_valid = all(
        (7.9 <= p.get("scale_gt", 0) <= 12.1) or p.get("found_gt", 1) == 0
        for p in pairs
    )
    check("10. Ground truth scale in [8, 12] for present pairs",
          scale_valid,
          "All present pairs within scale range" if scale_valid
          else "Some scale_gt out of range")

    # ── CHECK 11: No missing files ─────────────────────────────────────────
    missing_files = []
    for p in pairs[:200]:  # sample first 200
        split = p.get("split", "train")
        pair_id = p["pair_id"]
        for fname in ("reference.png", "search.png", "groundtruth.json"):
            fpath = os.path.join(dataset_dir, split, pair_id, fname)
            if not os.path.exists(fpath):
                missing_files.append(fpath)
    check("11. No missing files",
          len(missing_files) == 0,
          f"Missing: {missing_files[:5]}" if missing_files
          else "First 200 pairs fully intact")

    # ── CHECK 12: No duplicate pair IDs ───────────────────────────────────
    pair_ids = [p["pair_id"] for p in pairs]
    duplicates = [pid for pid in set(pair_ids) if pair_ids.count(pid) > 1]
    check("12. No duplicate pair IDs",
          len(duplicates) == 0,
          f"Duplicates: {duplicates[:5]}" if duplicates
          else f"All {n} pair IDs unique")

    # ── CHECK 13: No train/test leakage ───────────────────────────────────
    train_ids = set(p["pair_id"] for p in pairs if p.get("split") == "train")
    test_ids  = set(p["pair_id"] for p in pairs if p.get("split") == "test")
    val_ids   = set(p["pair_id"] for p in pairs if p.get("split") == "val")
    leakage = (train_ids & test_ids) | (train_ids & val_ids) | (val_ids & test_ids)
    check("13. No train/val/test leakage",
          len(leakage) == 0,
          f"Leaked pair IDs: {list(leakage)[:5]}" if leakage
          else f"Clean split: train={len(train_ids)}, val={len(val_ids)}, test={len(test_ids)}")

    # ── CHECK 14: Absent pairs lack embedded target ─────────────────────────
    absent_pairs = [p for p in pairs if p.get("found_gt", 1) == 0]
    absent_coord_ok = all(
        p.get("center_x", -1) == 0 and p.get("center_y", -1) == 0
        for p in absent_pairs
    )
    check("14. Absent pairs have GT coords (0, 0)",
          absent_coord_ok,
          f"{len(absent_pairs)} absent pairs checked" if absent_coord_ok
          else "Some absent pairs have non-zero coordinates")

    # ── CHECK 15: Reference/search relationship ────────────────────────────
    # For present pairs, verify the reference file is non-trivial (std > 5)
    ref_content_ok = True
    for p in [p for p in pairs[:50] if p.get("found_gt", 1) == 1]:
        split = p.get("split", "train")
        ref_path = os.path.join(dataset_dir, split, p["pair_id"], "reference.png")
        if os.path.exists(ref_path):
            img = cv2.imread(ref_path, cv2.IMREAD_GRAYSCALE)
            if img is not None and img.std() < 2.0:
                ref_content_ok = False
                break
    check("15. Reference images have meaningful content (std > 2)",
          ref_content_ok,
          "Verified reference images are non-trivial" if ref_content_ok
          else "Some reference images appear blank/uniform")

    # ── MANIFESTS ─────────────────────────────────────────────────────────
    manifests_dir = os.path.join(dataset_dir, "manifests")
    for split_name in ("train", "val", "test"):
        csv_path = os.path.join(manifests_dir, f"phase2_{split_name}_manifest.csv")
        check(f"CSV manifest exists: phase2_{split_name}_manifest.csv",
              os.path.exists(csv_path),
              csv_path)

    # ── FINAL RESULT ──────────────────────────────────────────────────────
    total_checks = passed + failed
    result = "PASS" if failed == 0 else f"FAIL ({failed}/{total_checks} checks failed)"

    # ── WRITE REPORT ──────────────────────────────────────────────────────
    report_path = os.path.join(dataset_dir, "phase2_dataset_validation.md")
    with open(report_path, "w") as f:
        f.write("# Phase-2 Dataset Validation Report\n\n")
        f.write(f"**Dataset directory**: `{os.path.abspath(dataset_dir)}`\n\n")
        f.write(f"**Overall result**: **{result}**\n\n")
        f.write(f"**Checks passed**: {passed}/{total_checks}\n\n")
        f.write("---\n\n")
        f.write("## Validation Checks\n\n")
        f.write("\n".join(report_lines))
        f.write("\n\n---\n")
        if issues:
            f.write("## Failed Checks\n\n")
            for issue in issues:
                f.write(f"- {issue}\n")
        else:
            f.write("## All checks passed (PASS)\n")

    print(f"\nValidation result: {result}")
    print(f"Report written to: {report_path}")

    return failed == 0


def main():
    parser = argparse.ArgumentParser(description="Validate Phase-2 Dataset")
    parser.add_argument("--dataset_dir", type=str, default="phase2_dataset")
    parser.add_argument("--expected_pairs", type=int, default=15000)
    args = parser.parse_args()
    ok = validate_phase2_dataset(args.dataset_dir, args.expected_pairs)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
