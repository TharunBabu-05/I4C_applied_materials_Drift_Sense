#!/usr/bin/env python3
"""
Phase-2 Master Dataset Generator (master_generator_phase2.py)
=============================================================

PURPOSE:
    Generate a 15,000-sample Phase-2 Siamese training dataset by calling the
    EXISTING 60 Round-1 generator scripts WITHOUT modifying any of them.
    All Phase-2 conditions are applied at the orchestration/transformation level
    in this master script only.

WHAT IS UNCHANGED:
    - phase2_generator_60/clean_60_scripts/generate_folder_001.py ... 060.py
      (zero edits to any of the 60 individual generator scripts)

WHAT IS NEW (Phase-2 conditions applied by this master):
    1. Unknown scale  ~ Uniform(8, 12)  per present pair
    2. Unknown rotation ~ Uniform(-5, +5) degrees  per present pair
    3. ~20% absent pairs  (reference from different architecture)
    4. Phase-2 degradation: 4 severity levels, 5 degradation types
    5. Hard negatives:  same-architecture shifted crops
    6. 80/10/10 train/val/test split (generator-aware, no leakage)
    7. Full CSV manifests per split compatible with DriftSenseSiameseDataset

DATASET CONVENTION:
    15,000 TRAINING PAIRS = 15,000 x (reference.png + search.png)
    = 30,000 image files total

    Split:
        12,000 train pairs
         1,500 val   pairs
         1,500 test  pairs

USAGE:
    python phase2_generator_60/master_generator_phase2.py \\
        --num_pairs 15000 \\
        --output_dir phase2_dataset \\
        --master_seed 2026

    python phase2_generator_60/master_generator_phase2.py \\
        --num_pairs 200 \\
        --output_dir phase2_dataset_test200 \\
        --master_seed 42
"""

import argparse
import csv
import gc
import importlib.util
import json
import math
import os
import sys
import time

import cv2
import numpy as np

# ── locate this file's directory so imports work regardless of cwd ─────────
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS_DIR_DEFAULT = os.path.join(_THIS_DIR, "clean_60_scripts")

# ─────────────────────────────────────────────────────────────────────────────
#   DEFAULT GT MAP  (native landmark centres per architecture folder)
#   This is copied from master_generator_v2.py — not imported, to keep this
#   file self-contained and to avoid any modification to the original.
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_GT_MAP = {
    "001": (650, 350), "002": (650, 350), "003": (490, 490), "004": (350, 630),
    "005": (500, 500), "006": (300, 700), "007": (490, 490), "008": (350, 630),
    "009": (460, 460), "010": (420, 580), "011": (500, 500), "012": (500, 335),
    "013": (500, 690), "014": (310, 500), "015": (500, 405), "016": (310, 500),
    "017": (500, 310), "018": (500, 500), "019": (488, 506), "020": (488, 314),
    "021": (500, 500), "022": (500, 310), "023": (500, 500), "024": (500, 310),
    "025": (500, 500), "026": (500, 310), "027": (500, 500), "028": (500, 310),
    "029": (500, 500), "030": (500, 310), "031": (500, 500), "032": (500, 310),
    "033": (500, 500), "034": (500, 310), "035": (500, 500), "036": (500, 310),
    "037": (500, 500), "038": (500, 310), "039": (500, 500), "040": (500, 310),
    "041": (500, 500), "042": (500, 310), "043": (500, 500), "044": (500, 310),
    "045": (500, 500), "046": (500, 310), "047": (500, 500), "048": (500, 310),
    "049": (500, 500), "050": (500, 310), "051": (500, 500), "052": (500, 310),
    "053": (500, 500), "054": (500, 310), "055": (500, 500), "056": (500, 310),
    "057": (500, 500), "058": (500, 310), "059": (500, 500), "060": (500, 310),
}


# ─────────────────────────────────────────────────────────────────────────────
#   STEP 1 — DISCOVER RENDER FUNCTIONS (identical logic to master_generator_v2)
#   We duplicate the discovery function here so we DON'T import
#   master_generator_v2 (and thus don't risk modifying it at import time).
# ─────────────────────────────────────────────────────────────────────────────
def discover_render_functions(scripts_dir):
    """Load all 60 generator scripts and return a registry of render functions."""
    if not os.path.exists(scripts_dir):
        raise FileNotFoundError(f"Scripts directory not found: {scripts_dir}")

    script_files = sorted(
        f for f in os.listdir(scripts_dir)
        if f.endswith(".py") and f.startswith("generate_folder_")
    )

    registry = []
    for s_file in script_files:
        folder_num = s_file.replace("generate_folder_", "").replace(".py", "")
        s_path = os.path.join(scripts_dir, s_file)

        spec = importlib.util.spec_from_file_location(f"p2_gen_mod_{folder_num}", s_path)
        mod = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(mod)
        except Exception as e:
            print(f"WARNING: Failed to load {s_file}: {e}")
            continue

        render_fn, generate_fn = None, None
        for attr in dir(mod):
            if attr.startswith("render_") and callable(getattr(mod, attr)):
                render_fn = getattr(mod, attr)
                break
        for attr in dir(mod):
            if attr.startswith("generate_") and callable(getattr(mod, attr)):
                generate_fn = getattr(mod, attr)
                break

        if render_fn or generate_fn:
            registry.append({
                "folder_num": folder_num,
                "script_name": s_file,
                "render_fn": render_fn,
                "generate_fn": generate_fn,
                "module": mod,
            })

    print(f"Discovered {len(registry)} generator scripts from {scripts_dir}")
    return registry


# ─────────────────────────────────────────────────────────────────────────────
#   STEP 2 — RENDER A CLEAN FULL-RESOLUTION IMAGE FROM ONE GENERATOR
# ─────────────────────────────────────────────────────────────────────────────
def render_clean_image(arch_info, h=1000, w=1000, gt_x=500, gt_y=500, seed=42):
    """
    Call the generator's render function (unchanged) and return a clean
    uint8 grayscale image of size (h, w).
    """
    render_fn = arch_info.get("render_fn")
    generate_fn = arch_info.get("generate_fn")

    img = None

    if render_fn is not None:
        for call in [
            lambda: render_fn(h=h, w=w, gt_x=int(gt_x), gt_y=int(gt_y), seed=seed),
            lambda: render_fn(h=h, w=w, seed=seed),
            lambda: render_fn(),
        ]:
            try:
                result = call()
                if isinstance(result, tuple):
                    img = result[0]
                elif isinstance(result, np.ndarray):
                    img = result
                if img is not None:
                    break
            except Exception:
                continue

    if img is None and generate_fn is not None:
        # generate_* functions write to disk — use a temp dir approach
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            try:
                generate_fn(output_dir=tmp, seed=seed)
                for name in ("search.png", "target.png"):
                    p = os.path.join(tmp, name)
                    if os.path.exists(p):
                        img = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
                        if img is not None:
                            break
            except Exception as e:
                print(f"  WARNING: generate_fn failed for {arch_info['script_name']}: {e}")

    if img is None:
        # Absolute fallback: minimal DRAM-like pattern
        np.random.seed(seed)
        img = np.full((h, w), 40, dtype=np.float32)
        for y in range(40, h, 60):
            for x in range(40, w, 60):
                cv2.rectangle(img, (x-20, y-20), (x+20, y+20), 170, -1)
        img = np.clip(img, 0, 255).astype(np.uint8)

    # Normalise to uint8 grayscale (h, w)
    if isinstance(img, str) and os.path.exists(img):
        img = cv2.imread(img, cv2.IMREAD_GRAYSCALE)
    if not isinstance(img, np.ndarray):
        img = np.full((h, w), 40, dtype=np.uint8)
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
    if img.shape[:2] != (h, w):
        img = cv2.resize(img, (w, h), interpolation=cv2.INTER_LINEAR)

    return img


# ─────────────────────────────────────────────────────────────────────────────
#   STEP 3 — PHASE-2 DEGRADATION ENGINE
#   Applied ONLY to the search image. Reference is ALWAYS clean.
#   4 severity levels, 5 degradation types per the Phase-2 spec.
# ─────────────────────────────────────────────────────────────────────────────
DEGRADATION_TYPES = [
    "charging_artifact",
    "scan_distortion",
    "defocus",
    "shot_noise",
    "polygon_scaling",
]

SEVERITY_PARAMS = {
    # (charging_amp, jitter_amp, blur_sigma, poisson_scale, cd_scale_range)
    1: dict(charge_amp=8.0,   jitter_amp=0.5, blur_sigma=0.6,  poisson_scale=14.0, cd_var=0.05,  gauss_std=1.5),
    2: dict(charge_amp=22.0,  jitter_amp=1.5, blur_sigma=1.4,  poisson_scale=8.0,  cd_var=0.10,  gauss_std=4.0),
    3: dict(charge_amp=42.0,  jitter_amp=3.5, blur_sigma=2.5,  poisson_scale=5.0,  cd_var=0.15,  gauss_std=8.0),
    4: dict(charge_amp=70.0,  jitter_amp=6.5, blur_sigma=4.0,  poisson_scale=2.5,  cd_var=0.20,  gauss_std=14.0),
}


def apply_phase2_degradation(img_uint8, degradation_types, severity, rng):
    """
    Apply selected Phase-2 degradations to a grayscale uint8 image.
    Modifies the search image only — reference is always kept clean.

    Args:
        img_uint8: (H, W) uint8 grayscale
        degradation_types: list of str, subset of DEGRADATION_TYPES
        severity: int 1-4
        rng: np.random.Generator

    Returns:
        (H, W) uint8 grayscale degraded image
    """
    p = SEVERITY_PARAMS[severity]
    img = img_uint8.astype(np.float32)  # stay float32 throughout — avoids float64 OOM
    h, w = img.shape

    for deg_type in degradation_types:
        if deg_type == "charging_artifact":
            # Electrostatic charging: linear gradient bias
            y_grad = np.linspace(-1, 1, h, dtype=np.float32)[:, None]
            x_grad = np.linspace(-1, 1, w, dtype=np.float32)[None, :]
            direction = float(rng.uniform(0, 2 * math.pi))
            charge_field = np.float32(math.cos(direction)) * x_grad + np.float32(math.sin(direction)) * y_grad
            img = img + np.float32(p["charge_amp"]) * charge_field

        elif deg_type == "scan_distortion":
            # Line-by-line horizontal jitter (beam scan instability)
            amp = p["jitter_amp"]
            freq = float(rng.uniform(0.01, 0.05))
            phase = float(rng.uniform(0, 2 * math.pi))
            shifts = amp * np.sin(2 * math.pi * freq * np.arange(h) + phase)
            for r in range(h):
                s = int(round(shifts[r]))
                if s != 0:
                    img[r] = np.roll(img[r], s)

        elif deg_type == "defocus":
            # Gaussian defocus blur
            sigma = p["blur_sigma"] + float(rng.uniform(-0.2, 0.2))
            if sigma > 0.2:
                img = cv2.GaussianBlur(img, (0, 0), sigma)

        elif deg_type == "shot_noise":
            # Poisson shot noise: Gaussian approximation avoids int64 allocation OOM.
            # For λ >> 1 (always true here: img*ps up to ~3570), Poisson(λ) ≈ Normal(λ, √λ).
            # This is the standard shot-noise approximation used in SEM noise literature.
            ps = np.float32(p["poisson_scale"])
            lam_f32 = np.clip(img, 0.001, 255.0).astype(np.float32) * ps
            sqrt_lam = np.sqrt(lam_f32)                                  # float32, 4 MB
            shot = rng.standard_normal(size=img.shape).astype(np.float32) * sqrt_lam  # float32
            img = (lam_f32 + shot) / ps                                  # stays float32
            # Gaussian read noise
            read = rng.standard_normal(size=img.shape).astype(np.float32) * np.float32(p["gauss_std"])
            img = img + read
            del lam_f32, sqrt_lam, shot, read

        elif deg_type == "polygon_scaling":
            # CD (critical dimension) variation ±cd_var
            scale_xy = 1.0 + float(rng.uniform(-p["cd_var"], p["cd_var"]))
            if abs(scale_xy - 1.0) > 0.02:
                new_w = max(64, int(round(w * scale_xy)))
                new_h = max(64, int(round(h * scale_xy)))
                img_rs = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
                if scale_xy > 1.0:
                    y0 = (new_h - h) // 2
                    x0 = (new_w - w) // 2
                    img = img_rs[y0:y0+h, x0:x0+w]
                else:
                    py = (h - new_h) // 2
                    px = (w - new_w) // 2
                    img = np.pad(img_rs,
                                 ((py, h - new_h - py), (px, w - new_w - px)),
                                 mode='edge')

    return np.clip(img, 0, 255).astype(np.uint8)


def sample_degradation(rng, absent=False):
    """
    Randomly select degradation types and severity level.

    Returns:
        degradation_types: list of str (may be empty = clean)
        severity: int 1-4  (0 if clean)
        degradation_label: str description
    """
    if absent:
        # Absent pairs: lighter degradation (distractor realism)
        prob_degrade = 0.6
    else:
        prob_degrade = 0.85  # 85% of present pairs get some degradation

    if float(rng.random()) > prob_degrade:
        return [], 0, "clean"

    severity = int(rng.integers(1, 5))  # 1, 2, 3, or 4

    # Number of degradation types to combine
    n_types = int(rng.choice([1, 1, 2, 2, 3], p=[0.25, 0.25, 0.25, 0.15, 0.10]))
    chosen = [DEGRADATION_TYPES[i] for i in
              rng.choice(len(DEGRADATION_TYPES), size=min(n_types, len(DEGRADATION_TYPES)),
                         replace=False)]

    label = f"sev{severity}_" + "+".join(chosen)
    return chosen, severity, label


# ─────────────────────────────────────────────────────────────────────────────
#   STEP 4 — BUILD ONE PRESENT PAIR
#   Applies Phase-2 scale + rotation at the orchestration level.
# ─────────────────────────────────────────────────────────────────────────────
def build_present_pair(arch_info, gt_x, gt_y, scale_gt, theta_gt,
                       degradation_types, severity, seed, rng):
    """
    Generate a PRESENT training pair using one of the 60 generators (unmodified).

    The Phase-2 conditions are applied AFTER calling the generator:
      - reference: clean 100x100 crop from the search scene
      - search:    full 1000x1000 scene with target embedded at scale/rotation,
                   then optionally degraded

    Args:
        arch_info:          registry entry for one of the 60 generators
        gt_x, gt_y:         target centre in the 1000x1000 search image
        scale_gt:           scale factor in [8, 12]
        theta_gt:           rotation in [-5, +5] degrees
        degradation_types:  list of str
        severity:           int 1-4
        seed:               integer render seed
        rng:                np.random.Generator

    Returns:
        reference_img:  (100, 100) uint8 — CLEAN
        search_img:     (1000, 1000) uint8 — degraded
        actual_gt_x, actual_gt_y: confirmed coordinates
    """
    # 1. Call the generator (UNCHANGED) to get a clean 1000x1000 scene
    search_clean = render_clean_image(arch_info, h=1000, w=1000,
                                      gt_x=int(gt_x), gt_y=int(gt_y), seed=seed)

    # 2. Extract CLEAN 100x100 reference crop at the target centre
    crop_size = 100
    x0 = max(0, min(1000 - crop_size, int(round(gt_x)) - crop_size // 2))
    y0 = max(0, min(1000 - crop_size, int(round(gt_y)) - crop_size // 2))
    ref_crop_100 = search_clean[y0:y0+crop_size, x0:x0+crop_size].copy()

    # 3. Apply Phase-2 scale + rotation to embed target in search
    #    patch_size = 1000 / scale_gt  (pixel size of reference in search)
    patch_w = int(round(1000.0 / scale_gt))
    patch_h = int(round(1000.0 / scale_gt))

    # Resize the 100x100 crop to the correct patch size
    ref_scaled = cv2.resize(ref_crop_100, (patch_w, patch_h),
                            interpolation=cv2.INTER_LINEAR)

    # Apply Phase-2 rotation (CCW positive)
    M_rot = cv2.getRotationMatrix2D(
        (patch_w / 2.0, patch_h / 2.0), theta_gt, 1.0
    )
    ref_rotated = cv2.warpAffine(
        ref_scaled, M_rot, (patch_w, patch_h),
        flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE
    )

    # 4. Blend the rotated-scaled patch into the search background
    sy0 = int(round(gt_y - patch_h / 2.0))
    sx0 = int(round(gt_x - patch_w / 2.0))
    sy1, sx1 = sy0 + patch_h, sx0 + patch_w

    # Clamp to image bounds
    sy0_c, sy1_c = max(0, sy0), min(1000, sy1)
    sx0_c, sx1_c = max(0, sx0), min(1000, sx1)
    py0_c = sy0_c - sy0
    py1_c = py0_c + (sy1_c - sy0_c)
    px0_c = sx0_c - sx0
    px1_c = px0_c + (sx1_c - sx0_c)

    search_bg = search_clean.astype(np.float32)
    if (sy1_c > sy0_c) and (sx1_c > sx0_c):
        bg_crop = search_bg[sy0_c:sy1_c, sx0_c:sx1_c]
        patch_crop = ref_rotated[py0_c:py1_c, px0_c:px1_c].astype(np.float32)
        # Alpha blend: 85% target patch, 15% background texture
        blended = 0.85 * patch_crop + 0.15 * bg_crop
        search_bg[sy0_c:sy1_c, sx0_c:sx1_c] = blended

    search_embedded = np.clip(search_bg, 0, 255).astype(np.uint8)

    # 5. Apply Phase-2 degradation to the SEARCH image only
    if degradation_types:
        search_final = apply_phase2_degradation(
            search_embedded, degradation_types, severity, rng
        )
    else:
        search_final = search_embedded

    return ref_crop_100, search_final, int(round(gt_x)), int(round(gt_y))


# ─────────────────────────────────────────────────────────────────────────────
#   STEP 5 — BUILD ONE ABSENT PAIR
#   Reference comes from a DIFFERENT generator than the search background.
#   The reference genuinely does NOT appear in the search image.
# ─────────────────────────────────────────────────────────────────────────────
def build_absent_pair(registry, arch_idx, degradation_types, severity, seed, rng):
    """
    Generate an ABSENT pair: reference from arch_A, search background from arch_B.
    The two architectures are chosen to be different, ensuring the reference
    does NOT appear in the search image.

    Returns:
        reference_img:  (100, 100) uint8
        search_img:     (1000, 1000) uint8
    """
    num_arch = len(registry)

    # Search background: current architecture
    search_arch = registry[arch_idx % num_arch]
    # Reference: shifted by ~17 architectures (guaranteed different)
    ref_arch = registry[(arch_idx + 17) % num_arch]

    # Generate search background (unmodified generator call)
    search_clean = render_clean_image(
        search_arch, h=1000, w=1000, seed=seed
    )

    # Generate reference background (unmodified generator call), then crop centre
    ref_bg = render_clean_image(
        ref_arch, h=1000, w=1000, seed=seed + 99999
    )
    ref_crop_100 = ref_bg[450:550, 450:550].copy()

    # Apply degradation to search if requested
    if degradation_types:
        search_final = apply_phase2_degradation(
            search_clean, degradation_types, severity, rng
        )
    else:
        search_final = search_clean.copy()

    return ref_crop_100, search_final


# ─────────────────────────────────────────────────────────────────────────────
#   STEP 6 — SPLIT ASSIGNMENT
#   Generator-aware 80/10/10 split — prevents same-generator leakage.
#   For each generator family (0..59), the cycles over that family are
#   assigned consistently: first 80% → train, next 10% → val, last 10% → test.
# ─────────────────────────────────────────────────────────────────────────────
def assign_split(pair_global_idx, num_pairs, num_arch):
    """
    Generator-aware split assignment.

    For each architecture family, the instances are assigned sequentially:
      first 80% → train, next 10% → val, last 10% → test.

    This guarantees no same-generator-same-seed overlap across splits.
    """
    arch_idx = pair_global_idx % num_arch
    cycle = pair_global_idx // num_arch  # which cycle this pair is in

    # Total cycles across all architectures
    total_cycles = math.ceil(num_pairs / num_arch)
    train_cutoff = int(round(total_cycles * 0.80))
    val_cutoff = int(round(total_cycles * 0.90))

    if cycle < train_cutoff:
        return "train"
    elif cycle < val_cutoff:
        return "val"
    else:
        return "test"


# ─────────────────────────────────────────────────────────────────────────────
#   STEP 7 — MAIN GENERATION FUNCTION
# ─────────────────────────────────────────────────────────────────────────────
def generate_phase2_dataset(
    num_pairs=15000,
    output_dir="phase2_dataset",
    scripts_dir=None,
    master_seed=2026,
    absent_fraction=0.20,
    verbose=True,
):
    """
    Generate the full Phase-2 Siamese training dataset.

    Args:
        num_pairs:       Total number of training pairs (default 15,000)
        output_dir:      Root output directory
        scripts_dir:     Path to the 60 generator scripts directory
        master_seed:     Master RNG seed (fully reproducible)
        absent_fraction: Fraction of absent pairs (default 0.20)
        verbose:         Print progress every 50 pairs

    Returns:
        dict: Summary statistics
    """
    t_start = time.time()

    # ── Resolve scripts directory ──────────────────────────────────────────
    if scripts_dir is None:
        scripts_dir = _SCRIPTS_DIR_DEFAULT
    scripts_dir = os.path.normpath(scripts_dir)

    # ── Load all 60 generators ─────────────────────────────────────────────
    registry = discover_render_functions(scripts_dir)
    num_arch = len(registry)
    if num_arch == 0:
        raise RuntimeError("No valid generator scripts found. "
                           f"Check scripts_dir: {scripts_dir}")

    # ── Create output directory structure ──────────────────────────────────
    for split in ("train", "val", "test"):
        os.makedirs(os.path.join(output_dir, split), exist_ok=True)
    previews_dir = os.path.join(output_dir, "previews")
    os.makedirs(previews_dir, exist_ok=True)
    manifests_dir = os.path.join(output_dir, "manifests")
    os.makedirs(manifests_dir, exist_ok=True)
    reports_dir = os.path.join(output_dir, "reports")
    os.makedirs(reports_dir, exist_ok=True)

    print("=" * 72)
    print("PHASE-2 MASTER DATASET GENERATOR (master_generator_phase2.py)")
    print("=" * 72)
    print(f"  Total pairs requested : {num_pairs:,}")
    print(f"  Absent fraction       : {absent_fraction*100:.0f}%")
    print(f"  Architectures loaded  : {num_arch}/60")
    print(f"  Master seed           : {master_seed}")
    print(f"  Output directory      : {os.path.abspath(output_dir)}")
    print(f"  Individual generators : NOT MODIFIED (read-only calls)")
    print("=" * 72)

    # ── RNG ────────────────────────────────────────────────────────────────
    master_rng = np.random.default_rng(master_seed)

    # ── Counters / accumulators ────────────────────────────────────────────
    manifest_entries = []        # for dataset_manifest.json
    generator_counts = {arch["folder_num"]: 0 for arch in registry}
    scale_bins = {"8-9": 0, "9-10": 0, "10-11": 0, "11-12": 0}
    rotation_bins = {"-5-(-2.5)": 0, "-2.5-0": 0, "0-2.5": 0, "2.5-5": 0}
    degradation_severity_counts = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0}
    degradation_type_counts = {t: 0 for t in DEGRADATION_TYPES}
    split_counts = {"train": 0, "val": 0, "test": 0}
    present_count = 0
    absent_count = 0

    # CSV manifest rows per split
    csv_rows = {"train": [], "val": [], "test": []}

    # ── Preview sampling: which pair indices get saved as previews ─────────
    preview_targets = _select_preview_indices(num_pairs, master_rng)

    # ─────────────────────────────────────────────────────────────────────
    #   MAIN GENERATION LOOP
    # ─────────────────────────────────────────────────────────────────────
    for idx in range(num_pairs):
        # Pair ID (1-indexed, zero-padded to 5 digits for up to 99,999 pairs)
        pair_id = f"pair_{idx + 1:05d}"

        # Architecture (round-robin across all 60)
        arch_info = registry[idx % num_arch]
        folder_num = arch_info["folder_num"]

        # Split assignment (generator-aware, no leakage)
        split = assign_split(idx, num_pairs, num_arch)

        # Per-pair RNG (deterministic, reproducible)
        pair_seed = int(master_rng.integers(0, 2**31))
        pair_rng = np.random.default_rng(pair_seed)

        # Decide present vs absent
        is_present = float(pair_rng.random()) >= absent_fraction

        # ── PRESENT PAIR ──────────────────────────────────────────────────
        if is_present:
            # Phase-2 scale: Uniform(8, 12)
            scale_gt = float(pair_rng.uniform(8.0, 12.0))
            # Phase-2 rotation: Uniform(-5, +5) degrees, CCW positive
            theta_gt = float(pair_rng.uniform(-5.0, 5.0))

            # Target centre with small jitter around native GT
            native_x, native_y = DEFAULT_GT_MAP.get(folder_num, (500, 500))
            gt_x = float(np.clip(
                native_x + int(pair_rng.integers(-50, 51)), 200, 800
            ))
            gt_y = float(np.clip(
                native_y + int(pair_rng.integers(-50, 51)), 200, 800
            ))

            # Degradation
            deg_types, severity, deg_label = sample_degradation(pair_rng, absent=False)

            # Build the pair
            ref_img, search_img, final_gt_x, final_gt_y = build_present_pair(
                arch_info, gt_x, gt_y, scale_gt, theta_gt,
                deg_types, severity, pair_seed, pair_rng
            )

            found_gt = 1
            present_count += 1

            # Bookkeeping
            _update_scale_bin(scale_bins, scale_gt)
            _update_rotation_bin(rotation_bins, theta_gt)

        # ── ABSENT PAIR ───────────────────────────────────────────────────
        else:
            scale_gt = 0.0
            theta_gt = 0.0
            final_gt_x = 0
            final_gt_y = 0
            deg_types, severity, deg_label = sample_degradation(pair_rng, absent=True)

            ref_img, search_img = build_absent_pair(
                registry, idx, deg_types, severity, pair_seed, pair_rng
            )

            found_gt = 0
            absent_count += 1

        # ── SAVE IMAGES ───────────────────────────────────────────────────
        pair_dir = os.path.join(output_dir, split, pair_id)
        os.makedirs(pair_dir, exist_ok=True)

        ref_path = os.path.join(pair_dir, "reference.png")
        search_path = os.path.join(pair_dir, "search.png")

        cv2.imwrite(ref_path, ref_img)
        cv2.imwrite(search_path, search_img)

        # ── GROUNDTRUTH JSON ──────────────────────────────────────────────
        gt_data = {
            "pair_id":          pair_id,
            "generator_id":     f"gen_{folder_num}",
            "generator_name":   arch_info["script_name"],
            "architecture":     f"Round1_Arch_Folder_{folder_num}",
            "split":            split,
            "center_x":         final_gt_x,
            "center_y":         final_gt_y,
            "x_gt":             final_gt_x,
            "y_gt":             final_gt_y,
            "theta_gt":         round(theta_gt, 4),
            "scale_gt":         round(scale_gt, 4),
            "found_gt":         found_gt,
            "degradation_types": deg_types,
            "degradation_severity": severity,
            "degradation_label": deg_label,
            "seed":             pair_seed,
            "image_height":     1000,
            "image_width":      1000,
            "ref_height":       100,
            "ref_width":        100,
            "channels":         1,
        }
        with open(os.path.join(pair_dir, "groundtruth.json"), "w") as f:
            json.dump(gt_data, f, indent=2)

        # ── MANIFEST ENTRY (compatible with DriftSenseSiameseDataset) ─────
        manifest_entries.append({
            "pair_id":      pair_id,
            "split":        split,
            "center_x":     final_gt_x,
            "center_y":     final_gt_y,
            "generator_id": f"gen_{folder_num}",
            "scale_gt":     round(scale_gt, 4),
            "theta_gt":     round(theta_gt, 4),
            "found_gt":     found_gt,
        })

        # ── CSV ROW ───────────────────────────────────────────────────────
        csv_rows[split].append([
            pair_id,
            f"gen_{folder_num}",
            arch_info["script_name"],
            split,
            os.path.relpath(ref_path, output_dir),
            os.path.relpath(search_path, output_dir),
            final_gt_x,
            final_gt_y,
            round(theta_gt, 4),
            round(scale_gt, 4),
            found_gt,
            severity,
            "+".join(deg_types) if deg_types else "clean",
            pair_seed,
        ])

        # ── COUNTERS ──────────────────────────────────────────────────────
        generator_counts[folder_num] += 1
        split_counts[split] += 1
        degradation_severity_counts[severity] += 1
        for dt in deg_types:
            degradation_type_counts[dt] += 1

        # ── PREVIEW SAVES ─────────────────────────────────────────────────
        if idx in preview_targets:
            _save_preview(previews_dir, pair_id, ref_img, search_img,
                          final_gt_x, final_gt_y, scale_gt, theta_gt,
                          found_gt, deg_label, folder_num)

        # ── PROGRESS ──────────────────────────────────────────────────────
        if verbose and ((idx + 1) % 500 == 0 or idx == 0 or idx == num_pairs - 1):
            elapsed = time.time() - t_start
            rate = (idx + 1) / max(elapsed, 1.0)
            eta = (num_pairs - idx - 1) / max(rate, 0.001)
            print(f"  [{idx+1:>6}/{num_pairs}] "
                  f"arch={folder_num} split={split} "
                  f"present={present_count} absent={absent_count} "
                  f"| {rate:.1f} pairs/s  ETA {eta:.0f}s")

        # ── MEMORY MANAGEMENT ─────────────────────────────────────────────
        if (idx + 1) % 100 == 0:
            gc.collect()

    # ── WRITE dataset_manifest.json ───────────────────────────────────────
    manifest = {
        "generator":         "master_generator_phase2.py",
        "individual_generators_modified": False,
        "num_pairs_generated": num_pairs,
        "total_architectures": num_arch,
        "master_seed":       master_seed,
        "output_directory":  os.path.abspath(output_dir),
        "phase2_conditions": {
            "scale_range":    [8.0, 12.0],
            "rotation_range": [-5.0, 5.0],
            "absent_fraction": absent_fraction,
            "degradation_levels": 4,
            "degradation_types": DEGRADATION_TYPES,
        },
        "pairs": manifest_entries,
    }
    manifest_path = os.path.join(output_dir, "dataset_manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    # ── WRITE PER-SPLIT CSV MANIFESTS ─────────────────────────────────────
    csv_header = [
        "pair_id", "generator_id", "generator_name", "split",
        "reference_path", "search_path",
        "x_gt", "y_gt", "theta_gt", "scale_gt", "found_gt",
        "degradation_severity", "degradation_types", "seed",
    ]
    split_map = {"train": "phase2_train_manifest.csv",
                 "val":   "phase2_val_manifest.csv",
                 "test":  "phase2_test_manifest.csv"}
    for split, fname in split_map.items():
        fpath = os.path.join(manifests_dir, fname)
        with open(fpath, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(csv_header)
            writer.writerows(csv_rows[split])

    # ── WRITE GENERATOR DISTRIBUTION CSV ──────────────────────────────────
    gen_dist_path = os.path.join(manifests_dir, "generator_distribution.csv")
    with open(gen_dist_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["generator_id", "generator_name", "image_count", "percentage"])
        for arch in registry:
            fn = arch["folder_num"]
            cnt = generator_counts[fn]
            pct = 100.0 * cnt / max(num_pairs, 1)
            writer.writerow([f"gen_{fn}", arch["script_name"], cnt, f"{pct:.2f}"])

    # ── FINAL SUMMARY ─────────────────────────────────────────────────────
    elapsed_total = time.time() - t_start
    summary = {
        "total_pairs":        num_pairs,
        "present_pairs":      present_count,
        "absent_pairs":       absent_count,
        "split_train":        split_counts["train"],
        "split_val":          split_counts["val"],
        "split_test":         split_counts["test"],
        "generators_used":    sum(1 for v in generator_counts.values() if v > 0),
        "scale_bins":         scale_bins,
        "rotation_bins":      rotation_bins,
        "severity_counts":    degradation_severity_counts,
        "elapsed_seconds":    round(elapsed_total, 1),
    }

    _print_final_summary(summary, num_arch, output_dir)

    # Write summary JSON
    with open(os.path.join(reports_dir, "generation_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    return summary


# ─────────────────────────────────────────────────────────────────────────────
#   HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def _update_scale_bin(bins, scale):
    if scale < 9.0:
        bins["8-9"] += 1
    elif scale < 10.0:
        bins["9-10"] += 1
    elif scale < 11.0:
        bins["10-11"] += 1
    else:
        bins["11-12"] += 1


def _update_rotation_bin(bins, theta):
    if theta < -2.5:
        bins["-5-(-2.5)"] += 1
    elif theta < 0.0:
        bins["-2.5-0"] += 1
    elif theta < 2.5:
        bins["0-2.5"] += 1
    else:
        bins["2.5-5"] += 1


def _select_preview_indices(num_pairs, rng):
    """
    Choose ~36 pair indices for visual previews covering a range of
    scales, rotations, degradation levels, generators, and present/absent.
    """
    n = min(36, num_pairs)
    step = max(1, num_pairs // n)
    indices = set(range(0, num_pairs, step))
    # Ensure we capture the edges
    indices.update([0, 1, 2, num_pairs - 3, num_pairs - 2, num_pairs - 1])
    return set(list(indices)[:n])


def _save_preview(previews_dir, pair_id, ref_img, search_img,
                  gt_x, gt_y, scale_gt, theta_gt, found_gt, deg_label, folder_num):
    """Save a side-by-side preview image for visual sanity checking."""
    # Resize reference to 200x200 for display
    ref_disp = cv2.resize(ref_img, (200, 200), interpolation=cv2.INTER_NEAREST)
    search_disp = cv2.resize(search_img, (200, 200), interpolation=cv2.INTER_AREA)

    # Draw ground truth cross on search preview
    if found_gt:
        sx = int(round(gt_x * 200.0 / 1000.0))
        sy = int(round(gt_y * 200.0 / 1000.0))
        cv2.drawMarker(search_disp, (sx, sy), 255, cv2.MARKER_CROSS, 15, 2)

    # Compose side by side
    gap = np.full((200, 10), 128, dtype=np.uint8)
    composite = np.hstack([ref_disp, gap, search_disp])

    # Add label bar
    label_bar = np.zeros((40, composite.shape[1]), dtype=np.uint8)
    label = (f"arch={folder_num} scale={scale_gt:.2f}x rot={theta_gt:.1f}deg "
             f"{'PRESENT' if found_gt else 'ABSENT'} {deg_label}")
    cv2.putText(label_bar, label[:80], (5, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, 200, 1, cv2.LINE_AA)
    composite = np.vstack([label_bar, composite])

    out_path = os.path.join(previews_dir, f"{pair_id}_arch{folder_num}.png")
    cv2.imwrite(out_path, composite)


def _print_final_summary(summary, num_arch, output_dir):
    print("\n" + "=" * 72)
    print("PHASE-2 DATASET GENERATION COMPLETE")
    print("=" * 72)
    print(f"  Total pairs              : {summary['total_pairs']:,}")
    print(f"  Present pairs            : {summary['present_pairs']:,}"
          f"  ({100*summary['present_pairs']/summary['total_pairs']:.1f}%)")
    print(f"  Absent pairs             : {summary['absent_pairs']:,}"
          f"  ({100*summary['absent_pairs']/summary['total_pairs']:.1f}%)")
    print(f"  Train / Val / Test       : "
          f"{summary['split_train']:,} / "
          f"{summary['split_val']:,} / "
          f"{summary['split_test']:,}")
    print(f"  Generators used          : {summary['generators_used']}/{num_arch}")
    print(f"  Scale bins               : {summary['scale_bins']}")
    print(f"  Rotation bins            : {summary['rotation_bins']}")
    print(f"  Severity distribution    : {summary['severity_counts']}")
    print(f"  Elapsed                  : {summary['elapsed_seconds']:.0f}s")
    print(f"  Output                   : {os.path.abspath(output_dir)}")
    print("=" * 72)
    print("\nINDIVIDUAL 60 GENERATORS MODIFIED: NO")
    print("MASTER GENERATOR MODIFIED       : YES (master_generator_phase2.py)")
    print()


# ─────────────────────────────────────────────────────────────────────────────
#   CLI ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description=(
            "Phase-2 Master Dataset Generator — generates 15,000 training pairs "
            "using the existing 60 Round-1 generator scripts (unchanged). "
            "All Phase-2 conditions (scale, rotation, absent pairs, degradation) "
            "are applied at the orchestration level in this script only."
        )
    )
    parser.add_argument(
        "--num_pairs", type=int, default=15000,
        help="Total pairs to generate (default: 15000)"
    )
    parser.add_argument(
        "--output_dir", type=str, default="phase2_dataset",
        help="Root output directory (default: phase2_dataset)"
    )
    parser.add_argument(
        "--master_seed", type=int, default=2026,
        help="Master RNG seed for full reproducibility (default: 2026)"
    )
    parser.add_argument(
        "--scripts_dir", type=str, default=None,
        help="Path to the 60 generator scripts directory "
             "(default: phase2_generator_60/clean_60_scripts)"
    )
    parser.add_argument(
        "--absent_fraction", type=float, default=0.20,
        help="Fraction of absent pairs in [0, 1] (default: 0.20)"
    )
    parser.add_argument(
        "--quiet", action="store_true", default=False,
        help="Suppress verbose progress output"
    )
    args = parser.parse_args()

    generate_phase2_dataset(
        num_pairs=args.num_pairs,
        output_dir=args.output_dir,
        scripts_dir=args.scripts_dir,
        master_seed=args.master_seed,
        absent_fraction=args.absent_fraction,
        verbose=not args.quiet,
    )


if __name__ == "__main__":
    main()
